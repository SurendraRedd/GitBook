import discord
from webserver import keep_alive
import os

''' client = discord.ext.commands.Bot(command_prefix = "!")

client.remove_command('help')

'''
client = discord.Client()

@client.event
async def on_ready():
  print("👍 Bot is up now!")

'''
@client.command(pass_context=True)
async def hel(ctx):
  
  author = ctx.message.author

  embed = discord.Embed(
    colour = discord.Colour.blue()
  )

  embed.set_author(name="Help:")
  embed.add_field(name="!help", value="Help command",inline=False)

  await client.send_message(author, embed=embed)
  await client.say("Message sent to your DMs! :thumbsup: ")
'''

@client.event
async def on_message(message):
  if message.content.startswith('$hello') or message.content.startswith('$hi') or message.content.startswith('$hai') or message.content.startswith('$what/s up'):
    await message.channel.send('👋Hello!')
  
  if message.content.startswith('$about'):
    embedVar = discord.Embed(title="Bot🤖", description="This bot helps to support on latest technologies", color=0x0099ff)
    await message.channel.send(embed=embedVar)

  if message.content.startswith('$how are you?'):
    await message.channel.send('Iam super👌. How are your?')

  if message.content.startswith('$Iam fine.') or        message.content.startswith('$Ok.') or 
  message.content.startswith('$Cool.'):
    await message.channel.send('Ok. How may i help you?')

  if message.content.startswith('$What is your name?'):
    await message.channel.send('My name is chitti the Robot!🤖')

  if message.content.startswith('$How you built?'):
    await message.channel.send('Using python🐍 & discord👨‍🎓')

  if message.content.startswith('$version'):
    await message.channel.send('Version 1.0.0')

  if message.content.startswith('$How to learn python?'):
    await message.channel.send('Refer the github repo - https://github.com/mGalarnyk/Python_Tutorials')

  if message.content.startswith('$bye'):
    await message.channel.send('👋Bye!. See you Soon.')
  
  if message.content.startswith('$What are you looking for?'):
    await message.channel.send('Nothing.Just like that.')

  if message.content.startswith('$Are you there?'):
    await message.channel.send('👍Yes.Tell me.')


keep_alive()
TOKEN = os.environ.get('DISCORD_BOT_TOKEN')
client.run(TOKEN)